﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kiosk_web.Common
{
    public class Global
    {

        public static string filter_condition = "";

        public static string urserRoll = "";

        public static string seq_qus = "";

        public static string roleCode = "";

        public static string userId = "";

        public static string path = "";

        public static string file_name = "";

        public static string guidvalue = "";

        public static string user_name = "";
      
        public static string org_code = "";

        

    }
}